//
//  SubDocumentsCollectionViewCell.swift
//  VideoPhotoSecrete2
//
//  Created by Macmini on 16/05/2023.
//

import UIKit

class SubDocumentsCollectionViewCell: UICollectionViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
